from flask import Flask 
skilles_app = Flask(__name__)


@skilles_app.route("/")

def homepage():
    return "Hello!"


@skilles_app.route("/about")
def about():
    return "About!"

if __name__ == "__main__":
    skilles_app.run()